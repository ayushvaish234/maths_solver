package com.av.mathssolver;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    Button calc, permute,hcf_lcm,power,root,numconv,vectors,matrices;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        //Button to launch Calculator
        calc = (Button) findViewById(R.id.Calc);
        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, calcactivity.class);
                startActivity(intent);
            }
        });

        //Button to launch number converter
        numconv = (Button) findViewById(R.id.Numconv);
        numconv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, numconv.class);
                startActivity(intent);
            }
        });

        //Button to launch vectors
        vectors = (Button) findViewById(R.id.Vectors);
        vectors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, vecSel.class);
                startActivity(intent);
            }
        });

        //Button to launch permutation combination
        permute = (Button) findViewById(R.id.Permute);
        permute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, permcom.class);
                startActivity(intent);
            }
        });

        //Button to launch HCF LCM
        hcf_lcm = (Button) findViewById(R.id.HCF);
        hcf_lcm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, hcflcm.class);
                startActivity(intent);
            }
        });

        //Button to launch power
        power = (Button) findViewById(R.id.power);
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Power.class);
                startActivity(intent);
            }
        });

        //Button to launch roots
        root = (Button) findViewById(R.id.Roots);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Root.class);
                startActivity(intent);
            }
        });

        //Button to launch matrices
        matrices = (Button) findViewById(R.id.Matrices);
        matrices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Matrix.class);
                startActivity(intent);
            }
        });
    }
}